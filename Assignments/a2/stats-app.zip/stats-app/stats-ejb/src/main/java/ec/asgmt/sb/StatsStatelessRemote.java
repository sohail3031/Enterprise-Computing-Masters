package ec.asgmt.sb;

import javax.ejb.Remote;

@Remote
// @RemoteBinding(jndiBinding = "java:jboss/exported/stats-web/MyStatsStateless")
public interface StatsStatelessRemote {
    public int getCount();
    
    public double getMin();
    
    public double getMax();
    
    public double getMean();
    
    public double getSTD();
    
    public String toString();
}
